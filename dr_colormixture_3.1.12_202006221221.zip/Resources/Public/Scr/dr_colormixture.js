// dr_colormixture.js part of typo3 extension dr_colormixture
function setColor( index ){
   $('#x' + index ).val( $('#col_' + index ).val() );
}
function changeColType( changeTo ){
    var recent_percent = $( 'input[name="tx_drcolormixture_ctr[display][recent_percent]"]' ).val();
    if( recent_percent == 1 ){
        for( z=1 ; z <= 3 ; ++z ) $( '#col_' + z ).val( 100 - $( '#col_' + z ).val() );
    }else{
        for( z=1 ; z <= 3 ; ++z ) $( '#col_' + z ).val( 255 - $( '#col_' + z ).val() );
    }
    for( z=1 ; z <= 3 ; ++z ) setColor(z);
    $( 'input[name="tx_drcolormixture_ctr[display][startcolors]"]' ).val(changeTo);
    $( 'input[name="tx_drcolormixture_ctr[display][percent]"]' ).val( recent_percent )
    $('#display' ).submit();
}
function padTo3Chars( char ){
    var strChar = char.toString();
    console.log( strChar + ': ' + strChar.length  );
    if( strChar.length == 1 ){
        return '00' + strChar;
    } else if( strChar.length == 2 ){
        return '0' + strChar;
    }
    return strChar;
    
}
function submitColors( piUid ){
    var rawUrl = $( '#url_' + piUid ).val();
    var target = $( 'input[name="tx_drcolormixture_ctr[display][target]"]' ).val() ;
    var startcolors = $( 'input[name="tx_drcolormixture_ctr[display][startcolors]"]' ).val() == 1 ? 1 : 0;
    var recent_percent = $( 'input[name="tx_drcolormixture_ctr[display][recent_percent]"]' ).val() == 1 ? 1 : 0;
    if( recent_percent ){
        var col1 = Math.round( ( $( '#col_1' ).val() * 2.55 ) );
        var col2 = Math.round( ( $( '#col_2' ).val() * 2.55 ) );
        var col3 = Math.round( ( $( '#col_3' ).val() * 2.55 ) );
    }else{
        var col1 = $( '#col_1' ).val();
        var col2 = $( '#col_2' ).val();
        var col3 = $( '#col_3' ).val();
    }
    
    var cleanUrl = rawUrl.replace( "##colors##", padTo3Chars( col1 ) + padTo3Chars( col2 ) + padTo3Chars( col3 ) );
    $('#img_' + piUid ).attr('src', cleanUrl ); 
    if( $('#myImage' ).length ){
        $('#myImage' ).attr('src', cleanUrl ); 
        $('#myImage' ).css('width', '100%' ); 
        $('#myImage' ).css('max-width', '1250px' ); 
    }else{
        $('#c' + target ).css('background-image', 'url(' + cleanUrl + ')' ); 
    }
    console.log(  '#c' + target + ' ' + padTo3Chars( col1 )  + ' ' +  padTo3Chars( col2 ) + ' ' +  padTo3Chars( col3 ) + ' '  );
}

// https://css-tricks.com/value-bubbles-for-range-inputs/
// und https://gist.github.com/dmolsen/3076696

function modifyOffset() {
    var el, newPoint, newPlace, offset, siblings, k , outputTag;
    width    = this.offsetWidth;
    newPoint = (this.value - this.getAttribute("min")) / (this.getAttribute("max") - this.getAttribute("min"));
    offset   = -1;
    if (newPoint < 0) { newPlace = 0;  }
    else if (newPoint > 1) { newPlace = width; }
    else { newPlace = width * newPoint + offset; offset -= newPoint;}
    siblings = this.parentNode.childNodes;
    for (var i = 0; i < siblings.length; i++) {
        sibling = siblings[i];
        if (sibling.id == this.id) { k = true; }
        if ((k == true) && (sibling.nodeName == "OUTPUT")) {
            outputTag = sibling;
        }
    }
    if( outputTag ){
        outputTag.style.left       = newPlace + "px";
        outputTag.style.marginLeft = offset + "%";
        outputTag.innerHTML        = this.value;
    }
}

function modifyInputs() {
    
    var inputs = document.getElementsByTagName("input");
    // loop trough all input-fields and make shore to affect only those with type "range"
    for (var i = 0; i < inputs.length; i++) {
        if (inxputs[i].getAttribute("type") == "range") {
            inputs[i].onchange = modifyOffset;

            // the following taken from http://stackoverflow.com/questions/2856513/trigger-onchange-event-manually
            if ("fireEvent" in inputs[i]) {
                inputs[i].fireEvent("onchange");
            } else {
                var evt = document.createEvent("HTMLEvents");
                evt.initEvent("change", false, true);
                inputs[i].dispatchEvent(evt);
            }
        }
    }
}

modifyInputs();
