<?php
namespace Dr\DrColormixture\Utility;

/***************************************************************
*  Copyright notice
*
*  (c) 2012 Daniel Rüegg <colormixture@verarbeitung.ch>
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
 * Image for the 'dr_colormixture' extension.
 * typo3conf/ext/dr_colormixture/Resources/Public/PHP/class.dr_colormixture_image.php
 *
 * @author	Daniel Rüegg <colormixture@verarbeitung.ch>
 * @package	TYPO3
 * @subpackage	tx_dr_colormixture
 */
class ImageUtility {
     
    /**
     * image
     *
     * @var str
     */
    Protected $img = '';
     
    /**
     * typ
     *
     * @var str
     */
    Protected $typ = 'a';
     
    /**
     * angles
     *
     * @var array
     */
    Private $angles = [ 1 => 0 , 2 => 120 , 3 => 240 ];
     
    /**
     * fontPath
     *
     * @var str
     */
    Protected $fontPath = '../Fonts/2B6D49_0_0.ttf';
    
    /**
     * opt
     *
     * @var array
     */
    Private $opt = [
        't' => 'a' , 
        'c' => '200'.'175'.'255' , 
        'r' => 450 , 
        'o' => 0 , 
        'b' => 2 , 
        'd' => 0 , 
        'i' => 0.8 , 
        's' => false
    ];
     
    /**
     * farbbaum
     *
     * @var array
     */
	Private $farbbaum = [
            'a' => [
                1 => [ 'name' => 'Rot'  , 'code' => [ 1 , 0 , 0 ] ] ,
                2 => [ 'name' => 'Grün' , 'code' => [ 0 , 1 , 0 ] ] ,
                3 => [ 'name' => 'Blau' , 'code' => [ 0 , 0 , 1 ] ] ,
                'text' => [ 255 , 255 , 255 ]  ,
                'background'  => [ 0 , 0 , 0 ] ,
                'center'  => [ 255 , 255 , 255 ]
            ] , 
            's' => [
                1 => [ 'name' => 'Yellow'  , 'code' => [ 1 , 1 , 0 ] ] ,
                2 => [ 'name' => 'Cyan'    , 'code' => [ 0 , 1 , 1 ] ] ,
                3 => [ 'name' => 'Magenta' , 'code' => [ 1 , 0 , 1 ] ] ,
                'text' => [ 0 , 0 , 0 ] ,
                'background'  => [ 255 , 255 , 255 ],
                'center'  => [ 0 , 0 , 0 ]
            ],
            'norm' => [ 
                'line'  => [ 85 , 85 , 85 ] ,
                'initialBackgr' => [ 170 , 170 , 170 ] 
            ]
        ];
     
    /**
     * invertValues
     *
     * @var array
     */
    Private $invertValues = [
            'types'  => [ 
                'a' => 's' , 
                's' => 'a' 
            ] , 
            'numbers' => [ 
                'a' => [
                    1 => 1 , 2=> 2 , 3 => 3 
                ] , 
                's' => [ 
                    1 => 2 , 2 => 3 , 3 => 1 
                ]
            ]
    ];

    /**
     * acceptableNames
     *
     * @var array
     */
    Public $acceptableNames = [
        't' => [ 'typ' , 'type'   ] , 
        'c' => [ 'col' , 'color'  ] , 
        'r' => [ 'rad' , 'radius' ] , 
        'o' => [ 'rot' , 'rotate' ] , 
        'b' => [ 'brd' , 'border' ] , 
        'd' => [ 'dir' , 'direction' ] , 
        'i' => [ 'ins' , 'inset' ] , 
        's' => [ 'sqr' , 'square' ] 
    ];
    
    /**
	 * The main method of the Image-Prozessor, called recursive by the Plugin
	 * options:
	 * t typ type      str [ a | s ]
	 * c col color     str [000000000 ... 255255255 ] rgb or cmy intensity
	 * r rad radius    int [ 10 ... 1576 ]
	 * o rot rotate    int [ 0 ... 360 ]
	 * b brd border    int [ 0 ... 1576+radius ]
	 * d dir direction bol [ 0 | 1 ] Display colors in clockwise Direction Uhrzeigersinn dir direction
	 * i ins inset     dec [ 0.51 ... 0.99 ] inset the distance between circles  ins inset
	 * s sqr square    bol [ 0 | 1 ] Display image in a square instead of crop. By cropping we get a rectangle.
	 *
	 * @param	array $options
	 * @return	The Background-Image
	 */
	function image( $options = [] ){
	
            $this->digestOptions( $options );
            
            $this->typ = strtolower( $this->opt['t'] ); // s | a
            
            // WIDTH, HEIGHT, X AND Y VALUES
            $this->pos = $this->getPositions();

            // create the image        
            $this->img = ImageCreateTruecolor( $this->pos['img-x'] , $this->pos['img-y'] ) or die;
            
            // create color-objects for the image. Extracts COLOR-OPTIONS out of incoming string.
            $color = $this->createColorObjects();

            // fill background with initial color
            imageFill( $this->img , 2 , 2 , $color['norm']['initialBackgr'] );
            
            // DRAW CIRCLES
            // first draw all 3 circles in a own line-color
            for( $circleNr = 1 ; $circleNr <= 3 ; ++$circleNr ){
                imageellipse ( $this->img , $this->pos['x'][$circleNr] , $this->pos['y'][$circleNr] , $this->opt['r'] * 2 , $this->opt['r'] * 2 , $color['norm']['line'] );
            }
            
            // filling backgrounds of variable colors
            for( $circleNr = 1 ; $circleNr <= 3 ; ++$circleNr ){
                // fill the seconary colors parts
                imageFill( $this->img ,  $this->pos['sec-x'][$circleNr] , $this->pos['sec-y'][$circleNr] , $color[ $this->invertValues['types'][ $this->typ ] ][ $this->invertValues['numbers'][ $this->typ ][$circleNr] ] );
                
                // fill the primary color circles with line-color to eliminate the lines
                imageFill( $this->img ,  $this->pos['x'][$circleNr] , $this->pos['y'][$circleNr] , $color['norm']['line'] );
                // fill the primary color circles
                imageFill( $this->img ,  $this->pos['x'][$circleNr] , $this->pos['y'][$circleNr] , $color[ $this->typ ][$circleNr] );
            }
            // fill center-color (tertiary color)
            imageFill( $this->img , $this->pos['img-x']/2 , $this->pos['img-y']/2 , $color['norm']['line'] );
            imageFill( $this->img , $this->pos['img-x']/2 , $this->pos['img-y']/2 , $color[ $this->opt['t'] ]['center'] );

            imageFill( $this->img , 3 , 3 , $color[ $this->opt['t'] ]['background'] );

            // TEXT
            for( $circleNr = 1 ; $circleNr <= 3 ; ++$circleNr ){
                // add LABEL TEXT for primary colors
                $this->writeColorNamePrimary( $circleNr , $color );
                // label for secondary color
                 $this->writeColorNameSecondary( $circleNr , $color  );
            }


            header('Content-Type: image/jpeg');
            imagejpeg($this->img);
            imagedestroy($this->img);

	}
    
    /**
	 * setOptions
	 *
	 * @param	array $options key-value pairs [ 't' => 'a' , ... ]
	 * @return	void
	 */
	Public function setOptions( $options = [] ){
        foreach( $options as $key => $value ) $this->opt[$key] = $value;
	}
    
    /**
	 * writeColorNameSecondary
	 *
	 * @param	int $circleNr
	 * @param	obj $color
	 * @return	array
	 */
	function writeColorNameSecondary( $circleNr , $color ){
            $inColor[1] = substr( $this->opt['c'] , 0 , 3 ); // R m [000 ... 255]  y
            $inColor[2] = substr( $this->opt['c'] , 3 , 3 ); // G y [000 ... 255]  c
            $inColor[3] = substr( $this->opt['c'] , 6 , 3 ); // B c [000 ... 255 ] m

            $fontsize = $this->opt['r'] / 15;
            $oType = $this->invertValues['types'][$this->typ];
            $text = $this->farbbaum[ $oType ][ $this->invertValues['numbers'][ $this->typ ][$circleNr] ]['name'];
            $aObjectInfo = imagettfbbox ( $fontsize , 0 , $this->fontPath , $text );
            $xOffset = (($aObjectInfo[2] - $aObjectInfo[6])/2);
            $yOffset = ($fontsize/2);
            imagettftext( $this->img , $fontsize , 0 , $this->pos['sec-x'][$circleNr] - $xOffset , $this->pos['sec-y'][$circleNr] + $yOffset , $color[ $oType ]['text'] , $this->fontPath,  $text );      
            imagettftext(
                $this->img , 
                $fontsize , 
                0 , 
                $this->pos['sec-x'][$circleNr] - $xOffset , 
                ($fontsize * 1.3 ) + $this->pos['sec-y'][$circleNr] + $yOffset , 
                $color[ $oType ]['text'] , 
                $this->fontPath,  $inColor[$circleNr]
            );
	}
    /**
	 * writeColorNamePrimary
	 *
	 * @param	int $circleNr
	 * @param	obj $color
	 * @return	array
	 */
	function writeColorNamePrimary( $circleNr , $color ){
            $inColor[1] = substr( $this->opt['c'] , 0 , 3 ); // R m [000 ... 255]  y
            $inColor[2] = substr( $this->opt['c'] , 3 , 3 ); // G y [000 ... 255]  c
            $inColor[3] = substr( $this->opt['c'] , 6 , 3 ); // B c [000 ... 255 ] m

            $aObjectInfo = imagettfbbox ( $this->opt['r']/8 , 0 , $this->fontPath , utf8_decode( $this->farbbaum[ $this->typ ][$circleNr]['name'] ) );
            $halfTextlength = ( $aObjectInfo[2] - $aObjectInfo[6] ) /2;
            $halfFontHeigth = ($this->opt['r']/16);
            
            $posX = $this->pos['x'][$circleNr] - $halfTextlength ;
            $posY = $this->pos['y'][$circleNr] + $halfFontHeigth;
            
            $text = utf8_decode( $this->farbbaum[ $this->typ ][$circleNr]['name'] );
            $fontsize =  $this->opt['r']/8;
            imagettftext( $this->img , $fontsize , 0 , $posX  , $posY  , $color[ $this->typ ]['text'] , $this->fontPath, $text  );        
            imagettftext( $this->img , ( $fontsize * 0.5 ) , 0 , $posX  , $posY + ( $fontsize * 0.6 ) , $color[ $this->typ ]['text'] , $this->fontPath, $inColor[$circleNr]  );        
	}
    
    /**
	 * createColorObjects
	 *
	 * @return	array
	 */
	function createColorObjects(){
            
            // extract COLOR-OPTIONS out of string
            // cut out from incoming string
            // the type (add / sub ) and the gradient of the 3 colors        
            $inColor[1] = substr( $this->opt['c'] , 0 , 3 ); // R m [000 ... 255]  y
            $inColor[2] = substr( $this->opt['c'] , 3 , 3 ); // G y [000 ... 255]  c
            $inColor[3] = substr( $this->opt['c'] , 6 , 3 ); // B c [000 ... 255 ] m
            
            // define basic colors
            foreach( $this->farbbaum['norm'] as $colorname => $aCol ){
                $color['norm'][$colorname] = imagecolorallocate( $this->img, $aCol[0] , $aCol[1] , $aCol[2] );
            }
            // center - color
//             $color['norm']['center'] = imagecolorallocate($this->img, $inColor[ 1 ] , $inColor[ 2 ] , $inColor[ 3 ] );
            
            // define variable colors for additive ans subtractive objects
            foreach( array_keys( $this->invertValues['types']) as $typ ) {
                // text colors for each type
                $color[ $typ ]['text'] = imagecolorallocate( $this->img, $this->farbbaum[ $typ ]['text'][0] , $this->farbbaum[ $typ ]['text'][1] , $this->farbbaum[ $typ ]['text'][2] );
                for( $z=1 ; $z<= 3; ++$z ) {
                    // additive and subtrractive colors
                    $color[ $typ ][ $z ] = imagecolorallocate($this->img, $inColor[ $z ] * $this->farbbaum[ $typ ][ $z ]['code'][0] , $inColor[ $z ] * $this->farbbaum[ $typ ][ $z ]['code'][1] , $inColor[ $z ] * $this->farbbaum[ $typ ][ $z ]['code'][2] );
                }
            }
            
            $color['a']['center'] = imagecolorallocate( $this->img, $aCol[0] , $aCol[1] , $aCol[2] );
            $color['s']['center'] = imagecolorallocate( $this->img, 255-$aCol[0] , 255-$aCol[1] , 255-$aCol[2] );
            
            $color['a']['background'] = imagecolorallocate( $this->img, $this->farbbaum[ 'a' ]['background'][0] , $this->farbbaum[ 'a' ]['background'][1] , $this->farbbaum[ 'a' ]['background'][2] );
            $color['s']['background'] = imagecolorallocate( $this->img, $this->farbbaum[ 's' ]['background'][0] , $this->farbbaum[ 's' ]['background'][1] , $this->farbbaum[ 's' ]['background'][2] );
            
            return $color;
	}
    
    /**
	 * getPositions
	 *
	 * @param	array $options
	 * @return	array
	 */
	function getPositions(){ 
            
            // The x-values get overwridden by substracting offset 
            // That is because the image is not 2x radius in width and height!
            $distance = $this->opt['r'] * $this->opt['i'];
            
            for( $z=1 ; $z <= 3 ; ++$z ){
                $pos['x'][ $z ] = ( $this->opt['r'] * 2 ) + $this->xDiff( $distance , $this->opt['o'] + $this->angles[ $z ]  , ( $this->opt['d'] == 1 ? -1 : +1 ) );
                $pos['y'][ $z ] = ( $this->opt['r'] * 2 ) + $this->yDiff( $distance , $this->opt['o'] + $this->angles[ $z ]  , ( $this->opt['d'] == 1 ? -1 : +1 ) );
            }
            
            
            if( $this->opt['s'] ){
                $pos['img-x']  = $this->opt['r'] * 4 ;
                $pos['img-y'] =  $this->opt['r'] * 4 ;
                
            }else{
                // choose smallest x and largest x an y
                $xOffset = min($pos['x']) - $this->opt['r'];
                $yOffset = min($pos['y']) - $this->opt['r'];
                // calculate margin (offset), widthand height
                $pos['img-x']  = (max($pos['x']) - min($pos['x']) ) + ( $this->opt['r'] * 2 ) + ( 2 * $this->opt['b'] ) +1 + 2;
                $pos['img-y'] = (max($pos['y']) - min($pos['y']) ) + ( $this->opt['r'] * 2 ) + ( 2 * $this->opt['b'] ) +1 + 2 ;
                // OVERRIDE the x- and y- values
                foreach( array_keys($pos['x']) as $z ) $pos['x'][$z] -= ( $xOffset - $this->opt['b'] -1 );
                foreach( array_keys($pos['y']) as $z ) $pos['y'][$z] += ( $this->opt['b'] - $yOffset );
                
            }
            // secondary positions
            foreach( [ 'x' , 'y' ] as $koord ) {
                for( $primeCircleNr=1 ; $primeCircleNr <= 3 ; ++$primeCircleNr ){
                    $secCircleNr = $this->invertValues['numbers']['s'][$primeCircleNr];
                    $difference = ( $pos[$koord][$secCircleNr] - $pos[$koord][$primeCircleNr] );
                    $halOfDifference = $difference / 2;
                    $posOfPrimeCol = $pos[$koord][$primeCircleNr];
                    $pos['sec-' . $koord ][$primeCircleNr] = $posOfPrimeCol + $halOfDifference ;
                }
            }

            return $pos;
	}
    
    /**
	 * digestOptions
	 *
	 * @param	array $options
	 * @return	void
	 */
	Private function digestOptions( $options = [] ){
            // get OPTIONS
            foreach( $this->opt as $name => $opt ){
                if( isset($options[$name]) ) {
                    if( !empty($this->opt[$name]) && empty($options[$name]) ) continue;
                    $this->opt[$name] = $options[$name];
                }
            }
            // reset default if subtractive order is selected: Adjust rotation by adding 120 degrees.
//             if( empty( $this->opt['o'] ) && $this->opt['t']=='s' ){
//                 $this->opt['o'] = 240;
//             }
	}
	
    /**
	 * xDiff
	 *  Ergibt Laenge der Gegenkathete "X" in Pixel
	 *  aus Hypothenusen-Laenge in pixel (radiant,strahl) 
	 *  und Winkel alpha in Grad
	 *
	 * @param	str $kDistanz
	 * @param	int $alpha
	 * @return	array
	 */
	Public function xDiff( $kDistanz , $alpha , $direction = 1 ){
	    $bogenmass = deg2rad( $alpha );
	    $sinus = sin( $direction * $bogenmass );
	    return round( ( $kDistanz * $sinus ) );
	}
	
    /**
	 * yDiff
     *  Ergibt Laenge der Ankathete "Y" in Pixel
	 *  aus Hypothenusen-Laenge in pixel (radiant,strahl) 
	 *  und Winkel alpha in Grad
	 *
	 * @param	str $kDistanz
	 * @param	int $alpha
	 * @return	int length
	 */
	Public function yDiff( $kDistanz , $alpha , $direction = 1 ){
	    $bogenmass = deg2rad( $alpha );
	    $cosinus = cos( $direction * $bogenmass );
	    return round( ( $kDistanz * $cosinus ) );
	}
}

?>
