<?php
namespace Dr\DrColormixture\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***
*
* This file is part of the "Colormixture" Extension for TYPO3 CMS.
*
* For the full copyright and license information, please read the
* LICENSE.txt file that was distributed with this source code.
*
*  (c) 2020 Daniel Rueegg
*
***/
/**
* DisplayController
*/
class DisplayController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
    * extKey
    * 
    * @var string
    */
    Private $extKey = 'dr_colormixture';
    
    /**
    * construct
    *
    * @return void
    */
    public function __construct()
    {
        $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
        $this->configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
        $this->contentObj = $this->configurationManager->getContentObject();
    }

    /**
    * action display
    * flexform: settings.
    *  colordadd 
    *  colordsub int [ 0 ... 5 ] order of the colors. Reihenfolge der additiven und subtraktiven Farben
    *  turnimage bol [ 1 | 0 ] Turn image. Bild drehen 180 Grad
    *  target    int [ uid eines entfernten contents ]
    *  hideme    bol [ 1 | 0 ] Hide this content-element. Content-Element verstecken.
    *  startcolors int [ 0 | 1 ] start typ additiv oder subtraktiv
    *  colvaladd_1 int [ 0 ... 255 ] start 1. additiv
    *  colvaladd_2 + colvaladd_3 ...
    *  colvalsub_1 int [ 0 ... 255 ] start 1. subtraktiv
    *  colvalsub_2 + colvalsub_3 ...
    * 
    * @return void
    */
    public function displayAction()
    {
    

        $display['percent'] =  $this->settings['percent'] ; // [ 0 | 1 ] fix from pluginConf
        $display['labels'] = $this->settings['labels']; // may change
        $display['startcolors'] = $this->settings['startcolors']; // [ 1 | 0 ] fix from pluginConf
        $display['t'] = $this->settings['startcolors'] ? 's' : 'a' ; // [ s | a ] may change
        $this->settings['turnimage'] = empty( $this->settings['turnimage'] ) ? 0 : intval($this->settings['turnimage']);
        
        if( !$this->request->hasArgument('display') ){
                // first call needs settings that may be overwridden by later calls
                for( $z = 1 ; $z <= 3 ; ++$z ){
                    $display['col_' . $z ] = $display['percent'] ? round( $this->settings['startvalue'][ $z ]/2.55 ) : $this->settings['startvalue'][ $z ] ;
                }
                
        }else{
                // comes from updateAction
                $arg = $this->request->getArgument('display');
                foreach( $arg as $name => $opt ) $display[ $name ] = $opt;

                $display['t'] = $display['startcolors'] ? 's' : 'a' ; // [ s | a ] may change

                if( !$display['col_1'] ) $display['col_1'] = 0;
                if( !$display['col_2'] ) $display['col_2'] = 0;
                if( !$display['col_3'] ) $display['col_3'] = 0;
                
                if( isset($arg['recent_percent']) && empty($arg['recent_percent']) && $arg['percent'] ){
                    for( $z=1 ; $z<=3 ; ++$z ) $display['col_' . $z] = round($display['col_' . $z]/2.55);
                }elseif( $arg['recent_percent'] && empty($arg['percent']) ){  
                    for( $z=1 ; $z<=3 ; ++$z ) $display['col_' . $z] = round($display['col_' . $z]*2.55);
                }

        }
        $invColVal = [];
        for( $z=1 ; $z<=3 ; ++$z ){
            $colorvalue = ( $display['percent'] ? 100 : 255 ) - $display['col_' . $z ];
            $format = '%0' . ( $display['percent'] ? 1 : 3 ) . 's';
            $invColVal['col_' . $z ] = sprintf( $format ,  $colorvalue );
        }
        $display['c_invert'] =  [ $invColVal['col_1'] , $invColVal['col_2'] ,  $invColVal['col_3'] ];
       
        if( !$display['percent'] ) $display['percent'] = 0;
        $colVal = [];
        for( $z=1 ; $z<=3 ; ++$z ){
            $colVal['col_' . $z ] = $display['percent'] ? sprintf('%03s' , round( ( $display['col_' . $z ] * 2.55 ) ) ) : sprintf('%03s' ,  $display['col_' . $z ] );
        }
        $display['c'] =  $colVal['col_1'] . $colVal['col_2'] .  $colVal['col_3'];
        
        // names of fix or overwridden variable changed
        $display['size'] = empty( $this->settings['size'] ) ? 300 : intval($this->settings['size']);
        $display['order'] = empty( $this->settings['order'] ) ? 0 : intval($this->settings['order']);
        $display['userchoise'] =  $this->settings['userchoise'];

        if( $display['t'] == 's' ){
             $display['o'] = $display['order'];
             
        }else{
            $display['o'] =  $this->settings['turnimage'];
        
        }
        
        // cosmetic! not more than 359 degrees
        if( $display['o'] > 360 ){
            $factor = floor( $display['o'] / 360 );
            $subtract = $factor * 360;
            $display['o'] = $display['o']-$subtract;
        }
        $display['d'] = $this->settings['order_clockwhise'];
        
        // default additional information
        $display['target'] = $this->settings['target'];
        $display['pluginUid'] = $this->contentObj->data['uid'];
        $display['debug'] = $this->settings['debug'];

        // labels [ 0:none , 1:percent , 2:bit ]
        
        $aAdrOpt[] = 't=' . $display['t'];
        $aAdrOpt[] = 'o=' . $display['o'];
        $aAdrOpt[] = 'c=' . $display['c'];
        $aAdrOpt[] = 'd=' . $display['d'];
        $aAdrOpt[] = 's=' . 1;
        $aAdrOpt[] = 'p=' . ( $display['percent'] == 1 ? 1 : 0 );
        $aAdrOpt[] = 'l=' . ( !$display['labels'] ? 0 : 1 );
        $aAdrOpt[] = 'z=' . time() . '';
        
        $display['imgadress'] = '/typo3conf/ext/dr_colormixture/Resources/Public/PHP/image.php?' . implode( '&' , $aAdrOpt ) ;
        // assign
        $this->view->assign('display', $display );
        
        $this->writeHeaderData( $display );
    }
    
    /**
    * writeHeaderData
    *
    * @param arr $display
    * @return boolean
    */
    public function writeHeaderData( $display ){
        // do some stoff with the header of website
        if( $display['target'] ){
            // maybe hide this plugin ( controler )
            if( $this->settings['hideme'] ) {
                $GLOBALS['TSFE']->setCSS(
                    $this->extKey . '_b' . $display['target']  , 
                    ' #c' . $display['pluginUid'] . ' { display:none; } ' 
                );
            }
            
            // set css for foreign content
            
            $cssKey = $this->extKey . '_a' . $display['target'];
            $styleList = " { " ; 
             $styleList .= "height:auto; min-height:" . $this->settings['size'] . "px;margin:0;padding:0; " ;
             $styleList .= "background-color:white; " ;
            $styleList .= "background-image: url('https://" . $_SERVER['SERVER_NAME'] . "" . $display['imgadress'] . "'); " ;
            $styleList .= "background-size:contain; " ;//. $this->settings['size'] . "px; " ;
             $styleList .= "background-repeat: no-repeat; " ;
            $styleList .= "} ";
            $GLOBALS['TSFE']->setCSS( $cssKey , '#c' . $display['target'] . $styleList );
        }
        return true;
    }

}
