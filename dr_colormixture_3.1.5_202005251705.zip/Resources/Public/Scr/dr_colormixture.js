// dr_colormixture.js part of typo3 extension colormixture
function slideColor( index ){
    $('#x' + index ).val( $('#col_' + index ).val() );
   // $('#display' ).submit();
}

// https://css-tricks.com/value-bubbles-for-range-inputs/
// und https://gist.github.com/dmolsen/3076696

function modifyOffset() {
    var el, newPoint, newPlace, offset, siblings, k , outputTag;
    width    = this.offsetWidth;
    newPoint = (this.value - this.getAttribute("min")) / (this.getAttribute("max") - this.getAttribute("min"));
    offset   = -1;
    if (newPoint < 0) { newPlace = 0;  }
    else if (newPoint > 1) { newPlace = width; }
    else { newPlace = width * newPoint + offset; offset -= newPoint;}
    siblings = this.parentNode.childNodes;
    for (var i = 0; i < siblings.length; i++) {
        sibling = siblings[i];
        if (sibling.id == this.id) { k = true; }
        if ((k == true) && (sibling.nodeName == "OUTPUT")) {
            outputTag = sibling;
        }
    }
    if( outputTag ){
        outputTag.style.left       = newPlace + "px";
        outputTag.style.marginLeft = offset + "%";
        outputTag.innerHTML        = this.value;
    }
}

function modifyInputs() {
    
    var inputs = document.getElementsByTagName("input");
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].getAttribute("type") == "range") {
            inputs[i].onchange = modifyOffset;

            // the following taken from http://stackoverflow.com/questions/2856513/trigger-onchange-event-manually
            if ("fireEvent" in inputs[i]) {
                inputs[i].fireEvent("onchange");
            } else {
                var evt = document.createEvent("HTMLEvents");
                evt.initEvent("change", false, true);
                inputs[i].dispatchEvent(evt);
            }
        }
    }
}

$(document).ready(function(){
});
        modifyInputs();
