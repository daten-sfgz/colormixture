<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Dr.DrColormixture',
            'Ctr',
            [
                'Display' => 'display,update'
            ],
            // non-cacheable actions
            [
                'Display' => 'display,update'
            ]
        );

        // wizards
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
            'mod {
                wizards.newContentElement.wizardItems.plugins {
                    elements {
                        ctr {
                            iconIdentifier = dr_colormixture-plugin-ctr
                            title = LLL:EXT:dr_colormixture/Resources/Private/Language/locallang.xlf:tx_dr_colormixture_ctr.name
                            description = LLL:EXT:dr_colormixture/Resources/Private/Language/locallang.xlf:tx_dr_colormixture_ctr.description
                            tt_content_defValues {
                                CType = list
                                list_type = drcolormixture_ctr
                            }
                        }
                    }
                    show = *
                }
            }'
        );
        $iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
        $iconRegistry->registerIcon(
            'dr_colormixture-plugin-ctr',
            \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
            ['source' => 'EXT:dr_colormixture/Resources/Public/Icons/user_plugin_ctr.svg']
        );
        
    }
);
