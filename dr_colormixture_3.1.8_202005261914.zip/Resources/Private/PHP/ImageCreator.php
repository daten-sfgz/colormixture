<?php
namespace Dr\DrColormixture\Php;

/***************************************************************
*  
*  VERSION 2.02
*  
*  Copyright notice
*
*  (c) 2020 Daniel Rüegg <colormixture@verarbeitung.ch>
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/

/**
 * Image for the 'dr_colormixture' extension.
 * typo3conf/ext/dr_colormixture/Resources/Public/PHP/class.dr_colormixture_image.php
 *
 * @author	Daniel Rüegg <colormixture@verarbeitung.ch>
 * @package	TYPO3
 * @subpackage	tx_dr_colormixture
 */
class ImageCreator {
     
    /**
     * pos
     *
     * @var arr
     */
    Public $pos = null;
     
    /**
     * fontpath
     *
     * @var arr
     */
    Public $fontpath = [ 'prim' => '../Fonts/helvetica.ttf' , 'sec' => '../Fonts/courier.ttf' ];

    /**
     * defaults
     *
     * @var array
     */
    Public $defaults = [
            't' => [ 
                'alias' => [ 'typ' , 'type'   ] , 
                'preset' => 'a' , 
                'affored' => 1 , 
                'type' => 'string' , 
                'desc' => '[ a  | s ] For additive or substractive colormix' 
            ], 
            'c' => [ 
                'alias' => [ 'col' , 'color'  ] , 
                'preset' => '200'.'175'.'245' , 
                'affored' => 1 , 
                'type' => 'string' , 
                'desc' => ' [000000000 ... 255255255 ] Color - intensity for rgb or cmy ' 
            ], 
            'r' => [ 
                'alias' => [ 'rad' , 'radius' ] , 
                'preset' => 450 , 
                'affored' => 1 , 
                'type' => 'integer' , 
                'desc' => ' [ 10 ... 1695 ]' 
            ],
            'o' => [ 
                'alias' => [ 'rot' , 'rotate' ] , 
                'preset' => 0 , 
                'type' => 'integer' , 'desc' => ' [ 0 ... 360 ]' ],
            'b' => [ 
                'alias' => [ 'brd' , 'border' ] , 
                'preset' => 2 , 
                'affored' => 1 , 
                'type' => 'integer' , 
                'desc' => ' [ 0 ... 2500 + radius ]' 
            ],
            'd' => [ 
                'alias' => [ 'dir' , 'direction' ] , 
                'preset' => false , 
                'type' => 'boolean' , 
                'desc' => ' [ 0 | 1 ] Display colors in clockwise Direction' 
            ],
            'i' => [ 
                'alias' => [ 'ins' , 'inset' ]  , 
                'preset' => 0.75 , 
                'affored' => 1 , 
                'type' => 'decimal' , 
                'desc' => ' [ 0.69 ... 0.99 ] Inset the distance between circles' 
            ],
            's' => [ 
                'alias' => [ 'sqr' , 'square' ] , 
                'preset' => false , 
                'type' => 'boolean' ,
                'desc' => ' [ 0 | 1 ] Display image in a square instead of crop. By cropping we get a rectangle.' 
            ],
            'p' => [ 
                'alias' => [ 'prc' , 'percent' ] , 
                'preset' => false , 
                'type' => 'boolean' , 
                'desc' => ' [ 0 | 1 ] Display colors in percent' 
            ],
            'l' => [ 
                'alias' => [ 'lab' , 'labels' ] , 
                'preset' => true , 
                'type' => 'boolean' , 
                'desc' => ' [ 0 | 1 ] Display labels' 
            ],
            'h' => [ 
                'alias' => [ 'hlp' , 'help' ,'info' , 'hilfe'] , 
                'type' => 'void' , 
                'desc' => ' [ none | 0 |  ] Empty or every string or integer. Eg. ?h prints out this help' ]
    ];
    
     
    /**
     * coltree
     *  
     *  typecolors-code: 
     *  0 x or 1x incomed,
     *  2 = value 255
     *  3 255 - incomed
     *  
     * @var array
     */
    Public $coltree = [
            'angles' => [ 1 => 0 , 2 => 120 , 3 => 240 ] ,
            'fixcolors' => [
                'black' =>          [ '000' , '000' , '000' ] ,
                'white' =>          [ '255' , '255' , '255' ] ,
                'line' =>           [ '085' , '085' , '085' ] ,
                'initialBackgr' =>  [ '170' , '170' , '170' ] ,
            ],
            'calc' => [
                0 => '000' ,
                1 => 'input-1' ,
                2 => 'input-2' ,
                3 => '255 - input-1' ,
                4 => '255 - input-2' ,
                5 => '255' ,
            ],
            'typecolors' => [
                'r' => [ 'name' => 'Rot'     , 'code_prim' => [ 1 , 0 , 0 ] , 'code_sec' => [ 5 , 3 , 4 ] ] ,
                'g' => [ 'name' => 'Grün'    , 'code_prim' => [ 0 , 1 , 0 ] , 'code_sec' => [ 4 , 5 , 3 ] ] ,
                'b' => [ 'name' => 'Blau'    , 'code_prim' => [ 0 , 0 , 1 ] , 'code_sec' => [ 3 , 4 , 5 ] ] ,
                'c' => [ 'name' => 'Cyan'    , 'code_prim' => [ 3 , 5 , 5 ] , 'code_sec' => [ 0 , 1 , 2 ] ] ,
                'm' => [ 'name' => 'Magenta' , 'code_prim' => [ 5 , 3 , 5 ] , 'code_sec' => [ 2 , 0 , 1 ] ] ,
                'y' => [ 'name' => 'Yellow'  , 'code_prim' => [ 5 , 5 , 3 ] , 'code_sec' => [ 1 , 2 , 0 ] ] ,
            ],
            'types' =>[
                'a' => [
                    'prim' => [ 1 => 'r' , 2 => 'g' , 3 => 'b' ] ,
                    'sec'  => [ 1 => 'y' , 2 => 'c' , 3 => 'm' ] ,
                    'text' => 'white'  ,
                    'breakpoint' => [ 0 , 255 ]  ,
                    'textsec' => 'black'  ,
                    'background'  => 'black' 
                ] ,
                
                's' => [
                    'prim' => [ 1 => 'c' , 2 => 'm' , 3 => 'y' ] ,
                    'sec'  => [ 1 => 'b' , 2 => 'r' , 3 => 'g' ] ,
                    'text'       => 'black' ,
                    'breakpoint' => [ 350 , 765 ] ,
                    'textsec' => 'white'  ,
                    'background' => 'white' 
                ]
            ]
       
    ];
     
    /**
     * typ
     *
     * @var str
     */
    Protected $typ = 'a';
    
    /**
     * opt
     *
     * @var array
     */
    Protected $opt = [];
    
    /**
	 * The main method of the Image-Prozessor, called recursive by the Plugin
	 * options: see this->defaults
	 *
	 * @param	array $options
	 * @return	The Image
	 */
	Public function createImage( $options = [] ){
	
            $this->digestOptions( $options );
            
            if( isset( $this->opt['h'] ) ) {
                print( $this->getHelp() ); 
                die();
            }

            $this->typ = strtolower( $this->opt['t'] ); // s | a
            
            // WIDTH, HEIGHT, X AND Y VALUES
            $this->pos = $this->getPositions();

            // create the image        
            $image = ImageCreateTruecolor( $this->pos['img-x'] , $this->pos['img-y'] ) or die;
            
            // create color-objects for the image. Extracts COLOR-OPTIONS out of incoming string.
            $color = $this->createColorObjects( $image );

            // fill background with initial color
            imageFill( $image , 2 , 2 , $color['norm']['initialBackgr'] );
            
            // DRAW CIRCLES
            // first draw all 3 circles in a own line-color
            for( $circleNr = 1 ; $circleNr <= 3 ; ++$circleNr ){
                imageellipse ( $image , $this->pos['x'][$circleNr] , $this->pos['y'][$circleNr] , $this->opt['r'] * 2 , $this->opt['r'] * 2 , $color['norm']['line'] );
            }
            
            // fill backgrounds of variable colors
            for( $circleNr = 1 ; $circleNr <= 3 ; ++$circleNr ){
                //SECONDARY
                // fill the seconary colors parts
                $colKeySec = $this->coltree['types'][ $this->typ ]['sec'][$circleNr];
                $col = $color[ $this->typ ]['sec'][$circleNr];
                imageFill( $image ,  $this->pos['sec-x'][$circleNr] , $this->pos['sec-y'][$circleNr] , $col );
                
                // PRIMARY
                // fill the primary color circles with line-color to eliminate the lines
                imageFill( $image ,  $this->pos['x'][$circleNr] , $this->pos['y'][$circleNr] , $color['norm']['line'] );
                // fill the primary color circles
                imageFill( $image ,  $this->pos['x'][$circleNr] , $this->pos['y'][$circleNr] , $color[ $this->typ ]['prim'][$circleNr] );
            }
            // fill center-color (tertiary color)
            imageFill( $image , $this->pos['img-x']/2 , $this->pos['img-y']/2 , $color['norm']['line'] );
            imageFill( $image , $this->pos['img-x']/2 , $this->pos['img-y']/2 , $color[ $this->typ ]['center'] );

            imageFill( $image , 3 , 3 , $color[ $this->typ ]['background'] );

            // TEXT
            if( $this->opt['l'] == true ){
                    for( $circleNr = 1 ; $circleNr <= 3 ; ++$circleNr ){
                        // add LABEL TEXT for primary colors
                        $this->writeLabelsPrimary( $circleNr , $color , $image );
                        // label for secondary color
                        $this->writeLabelsSecondary( $circleNr , $color , $image );
                    }
            }


            header('Content-Type: image/jpeg');
            imagejpeg($image);
            imagedestroy($image);

	}
    
    /**
	 * digestOptions
	 *
	 * @param	array $options
	 * @return	void
	 */
	Private function digestOptions( $options = [] ){
            // set calculable coltree option contratype
            foreach( array_keys( $this->coltree['types'] ) as $tp ) $loopType[] = $tp;
            $this->coltree['types'][ $loopType[0] ]['contratype'] = $loopType[1];
            $this->coltree['types'][ $loopType[1] ]['contratype'] = $loopType[0];
            
            // set OPTIONS from incomed or presets
            $allowedOpt = [];
            foreach( $this->defaults as $key => $moreKeys ){
                if( isset( $options[$key] ) && ( !$this->defaults[$key]['affored'] || !empty( $options[$key] ) ) ) {
                    $allowedOpt[$key] = $options[$key];
                }else{
                    foreach( $moreKeys['alias'] as $longKey ) {
                        if( isset( $options[$longKey] ) && ( !$this->defaults[$key]['affored'] || !empty( $options[$longKey] ) ) ) {
                            $allowedOpt[$key] = $options[$longKey];
                        }
                    }
                }
            }
            if( isset($allowedOpt['t']) && !isset( $this->coltree['types'][ $allowedOpt['t'] ] ) ) unset( $allowedOpt['t'] );
            if( isset($allowedOpt['c']) && strlen($allowedOpt['c']) != 9 ) unset( $allowedOpt['c'] );
            if( isset($allowedOpt['r']) && ( $allowedOpt['r'] < 10 || $allowedOpt['r'] > 1695 ) ) unset( $allowedOpt['r'] );
            if( isset($allowedOpt['i']) && ( $allowedOpt['i'] < 0.69 || $allowedOpt['i'] > 0.99 ) ) unset( $allowedOpt['i'] );
            
            foreach( $this->defaults as $key => $preDef ){
                $this->opt[$key] =  isset($allowedOpt[$key]) ? $allowedOpt[$key] : $preDef['preset'];
            }

            // extract COLOR-OPTIONS out of string
            // cut out from incoming string the gradient of the 3 colors        
            $this->opt['inp-c'][1] = substr( $this->opt['c'] , 0 , 3 ); // R m [000 ... 255]  y
            $this->opt['inp-c'][2] = substr( $this->opt['c'] , 3 , 3 ); // G y [000 ... 255]  c
            $this->opt['inp-c'][3] = substr( $this->opt['c'] , 6 , 3 ); // B c [000 ... 255 ] m
            
            return true;
	}
	
    /**
	 * getHelp
	 *
	 * @return	sttr
	 */
	Private function getHelp(){
        $strOut = '<h1>Colormixture Help</h1><h2>Possible Options</h2><table border="0" style="border:1px solid black;border-collapse: separate; border-spacing:8px 1px;">';
        $strOut .= '<tr><th>Key</th><th style="text-align:left;">Key Aliases </th><th style="text-align:left;">Type</th><th style="text-align:left;">Description</th></tr>';
        foreach( $this->defaults as $key => $aDef ) {
            $strOut .='<tr><td>' . $key . '</td><td>' . implode( ', ' , $aDef['alias'] ) . '</td><td>' . $aDef['type'] . '</td><td>' . $aDef['desc'] . '</td></tr>';
        }
        
        $aHtQuery = [];
        foreach( $this->defaults as $key => $aDef ) {
            if( $aDef['preset'] ) $aHtQuery[] = $key . '=' . $aDef['preset'];
        }
        $sQuery = '?' . implode( '&' , $aHtQuery );
        $strOut .= '</table><h2>Example link with default values</h2>...<a href="' . $sQuery . '">' . $sQuery . '</a>';
        return  $strOut ;
        
        
	}

	/**
	 * calcColorCodeToValue
     *  
	 * @return	array $colorvalues
	 */
	Private function calcColorCodeToValue(){
            for( $circleNr = 1 ; $circleNr <= 3; ++$circleNr ) {

                foreach( [ 'prim' , 'sec' ] as $pos ){

                    $colKey = $this->coltree['types'][ $this->typ ][$pos][ $circleNr ];
                    $code = $this->coltree['typecolors'][ $colKey ]['code_' . $pos ]; // eg. 3 , 3 , 2 for yellow prim
                    $aCircleNr = [ 1 => $circleNr , 2 => ( $circleNr == 3 ? 1 : $circleNr + 1 ) , 3 => ( $circleNr == 1 ? 3 : $circleNr - 1) ];
                    $irp = [];
                    for( $cNr = 1 ; $cNr <= 3 ; ++$cNr ) $irp['input-' . $cNr] = intval( $this->opt['inp-c'][$aCircleNr[$cNr]] );
                    foreach( $this->coltree['calc'] as $calcNr => $strCalc ){
                        $replaced = str_replace( array_keys( $irp ) , $irp , $strCalc );
                        eval( '$calculated[' . $calcNr . '] = ' .  $replaced . ';' );
                    }
                    for( $n = 0 ; $n <= 2 ; ++$n ) $colorvalues[ $pos ][ $circleNr ][ $n ] = $calculated[ $code[ $n ] ];
                    
                }
            }
            return $colorvalues;
	}

	/**
	 * createColorObjects
     *  typecolors-code: 
     *  0 set 0
     *  1 set the incomed value,
     *  2 set 255
     *  3 calc 255 - incomed
     *  
	 * @param	obj $image
	 * @return	array
	 */
	Private function createColorObjects( $image ){
            // define variable colors for additive ans subtractive objects
            $aCodizes = $this->calcColorCodeToValue();
            foreach( $aCodizes as $pos => $circDef ){
                foreach( $circDef as $circleNr => $calcCol ){
                    $color[ $this->typ ][ $pos ][ $circleNr ] = imagecolorallocate( $image , $calcCol[0] , $calcCol[1] , $calcCol[2] );
                }
                
            }
            
            // define fixcolors colors
            foreach( $this->coltree['fixcolors'] as $colorname => $aCol ){
                $color['norm'][$colorname] = imagecolorallocate( $image, $aCol[0] , $aCol[1] , $aCol[2] );
            }
            
            // text colors for each type
            foreach( array_keys($this->coltree['types']) as $type ) {
                $colNameFirst = $this->coltree['types'][ $type ]['text'];
                $color[ $type ]['text'] = imagecolorallocate( $image, $this->coltree['fixcolors'][$colNameFirst][0] , $this->coltree['fixcolors'][$colNameFirst][1] , $this->coltree['fixcolors'][$colNameFirst][2] );
                
                $colNameSecond = $this->coltree['types'][ $type ]['textsec'];
                $color[ $type ]['textsec'] = imagecolorallocate( $image, $this->coltree['fixcolors'][$colNameSecond][0] , $this->coltree['fixcolors'][$colNameSecond][1] , $this->coltree['fixcolors'][$colNameSecond][2] );
            }
            
            // center - color
            $color['a']['center'] = imagecolorallocate( $image , $this->opt['inp-c'][1] , $this->opt['inp-c'][2] , $this->opt['inp-c'][3] );
            $color['s']['center'] = imagecolorallocate( $image, 255-$this->opt['inp-c'][1] , 255-$this->opt['inp-c'][2] , 255-$this->opt['inp-c'][3] );
            
            foreach( $this->coltree['types'] as $type => $typDef ){
                $colKey = $this->coltree['types'][$type]['background'];
                $color[ $type ]['background'] = imagecolorallocate( $image, $this->coltree['fixcolors'][$colKey][0] , $this->coltree['fixcolors'][$colKey][1] , $this->coltree['fixcolors'][$colKey][2] );
            }
            
            return $color;
	}
    
    /**
	 * getPositions
	 *
	 * @param	array $options
	 * @return	array
	 */
	Private function getPositions(){ 
            
            // The x-values get overwridden by substracting offset 
            // That is because the image is not 2x radius in width and height!
            $distance = $this->opt['r'] * $this->opt['i'];
            
            for( $cNr=1 ; $cNr <= 3 ; ++$cNr ){
                $pos['x'][ $cNr ] = ( $this->opt['r'] * 2 ) + $this->xDiff( $distance , $this->opt['o'] + $this->coltree['angles'][ $cNr ]  , ( $this->opt['d'] == 1 ? -1 : +1 ) );
                $pos['y'][ $cNr ] = ( $this->opt['r'] * 2 ) + $this->yDiff( $distance , $this->opt['o'] + $this->coltree['angles'][ $cNr ]  , ( $this->opt['d'] == 1 ? -1 : +1 ) );
            }
            
            
                
            //}else{
                // choose smallest x and largest x an y
                $xOffset = min($pos['x']) - $this->opt['r'];
                $yOffset = min($pos['y']) - $this->opt['r'];
                // calculate margin (offset), width and height
                $pos['img-x']  = (max($pos['x']) - min($pos['x']) ) + ( $this->opt['r'] * 2 ) + ( 2 * $this->opt['b'] ) +1 + 2;
                $pos['img-y'] = (max($pos['y']) - min($pos['y']) ) + ( $this->opt['r'] * 2 ) + ( 2 * $this->opt['b'] ) +1 + 2 ;
                // OVERRIDE the x- and y- values
                foreach( array_keys($pos['x']) as $cNr ) $pos['x'][$cNr] -= ( $xOffset - $this->opt['b'] -1 );
                foreach( array_keys($pos['y']) as $cNr ) $pos['y'][$cNr] += ( $this->opt['b'] - $yOffset );
                
            if( $this->opt['s']){
                if( $pos['img-x'] > $pos['img-y'] ){
                    $pos['img-y'] = $pos['img-x'];
                }else{
                    $pos['img-x'] = $pos['img-y'];
                }
            }
            // secondary positions
            foreach( [ 'x' , 'y' ] as $koord ) {
                for( $primeCircleNr=1 ; $primeCircleNr <= 3 ; ++$primeCircleNr ){
                    $secCircleNr = $primeCircleNr > 2 ? 1 : $primeCircleNr+1;
                    $difference = ( $pos[$koord][$secCircleNr] - $pos[$koord][$primeCircleNr] );
                    $halOfDifference = $difference / 2;
                    $posOfPrimeCol = $pos[$koord][$primeCircleNr];
                    $pos['sec-' . $koord ][$primeCircleNr] = $posOfPrimeCol + $halOfDifference ;
                }
            }

            return $pos;
	}
	
    /**
	 * writeLabelsPrimary
	 *
	 * @param	int $circleNr
	 * @param	obj $color
	 * @param	obj $image
	 * @return	array
	 */
	Private function writeLabelsPrimary( $circleNr , $color , $image ){
            
            $colKey = $this->coltree['types'][ $this->typ ]['prim'][ $circleNr ]; // r g b c m y
            $aText['top'] = utf8_decode($this->coltree['typecolors'][ $colKey ]['name'] );
            $aFontsize['top'] =  $this->opt['r']/8;

            $aObjectInfo['top'] = imagettfbbox ( $aFontsize['top'] , 0 , $this->fontpath['prim'] , $aText['top'] );
            $aHalfTextlength['top'] = ( $aObjectInfo['top'][2] - $aObjectInfo['top'][6] ) /2;
            
            $aXpos['top'] = $this->pos['x'][$circleNr] - $aHalfTextlength['top'] ;
            $aYpos['top'] = $this->pos['y'][$circleNr] + ($aFontsize['top']/2);
            
            imagettftext( $image , $aFontsize['top'] , 0 , $aXpos['top']  , $aYpos['top']  , $color[ $this->typ ]['text'] , $this->fontpath['prim'], $aText['top']  );
            
            $aFontsize['but'] =  $aFontsize['top'] * 0.7 ;
            $aText['but'] = $this->opt['p'] ? round($this->opt['inp-c'][$circleNr]/2.55) . '%' : $this->opt['inp-c'][$circleNr] ;
            
            $aObjectInfo['but'] = imagettfbbox ( $aFontsize['but'] , 0 , $this->fontpath['prim'] , $aText['but'] );
            $aHalfTextlength['but'] = ( $aObjectInfo['but'][2] - $aObjectInfo['but'][6] ) /2;

            $aXpos['but'] = $this->pos['x'][$circleNr] - $aHalfTextlength['but'] ;
            $aYpos['but'] = $this->pos['y'][$circleNr] + ($aFontsize['but'] * 2 );
            imagettftext( $image , ( $aFontsize['but']  ) , 0 , $aXpos['but']  , $aYpos['but'] , $color[ $this->typ ]['text'] , $this->fontpath['prim'] ,  $aText['but'] );        
	}
    
    /**
	 * writeLabelsSecondary
	 *
	 * @param	int $circleNr
	 * @param	obj $color
	 * @param	obj $image
	 * @return	array
	 */
	Private function writeLabelsSecondary( $circleNr , $color , $image ){

            $fontsize = $this->opt['r'] / 15;
            $aCodizes = $this->calcColorCodeToValue();
            
            // change color if to bright (subtractive) or too dark (additive)
            $colorSum = round( intval( $aCodizes['sec'][$circleNr][0] ) + intval( $aCodizes['sec'][$circleNr][1] ) + intval( $aCodizes['sec'][$circleNr][2] ) );
            if( 
                $colorSum >= $this->coltree['types'][ $this->typ ]['breakpoint'][0] && 
                $colorSum <= $this->coltree['types'][ $this->typ ]['breakpoint'][1] 
            ) {
                $tectcolor = $color[ $this->typ ]['text'];
            }else{
                $tectcolor = $color[ $this->typ ]['textsec'];
            }

            $aText['top'] = $this->opt['t']=='a' ?  'RGB' : 'CMY';
            $aText['top'] .= $this->opt['p'] ?  ' %' : '';
            $aObjectInfo['top'] = imagettfbbox ( $fontsize , 0 , $this->fontpath['sec'] , $aText['top'] );
            $aLabelWidth['top'] = (($aObjectInfo['top'][2] - $aObjectInfo['top'][6])/2);
            $aXpos['top'] = $this->pos['sec-x'][$circleNr] - $aLabelWidth['top'] ;
            $aYpos['top'] =  $this->pos['sec-y'][$circleNr] - ($fontsize/2);
            imagettftext( $image , $fontsize , 0 ,$aXpos['top'] , $aYpos['top'] , $tectcolor , $this->fontpath['sec'],  $aText['top'] );      
            
            
            if($this->opt['t'] =='s' ){
                $aCodizes['sec'][$circleNr][0] = 255 - $aCodizes['sec'][$circleNr][0];
                $aCodizes['sec'][$circleNr][1] = 255 - $aCodizes['sec'][$circleNr][1];
                $aCodizes['sec'][$circleNr][2] = 255 - $aCodizes['sec'][$circleNr][2];
            }
            if($this->opt['p'] ){
                $aText['but'] = '' . round($aCodizes['sec'][$circleNr][0]/2.55) . ' ' ;
                $aText['but'] .= '' . round($aCodizes['sec'][$circleNr][1]/2.55) . ' ';
                $aText['but'] .= '' . round($aCodizes['sec'][$circleNr][2]/2.55);
            }else{
                $aText['but'] = '' . $aCodizes['sec'][$circleNr][0] . ' ';
                $aText['but'] .= '' . $aCodizes['sec'][$circleNr][1] . ' '; 
                $aText['but'] .= '' . $aCodizes['sec'][$circleNr][2]; 
            }
            
            $aObjectInfo['but'] = imagettfbbox ( $fontsize , 0 , $this->fontpath['sec'] , $aText['but'] );
            $aLabelWidth['but'] = (($aObjectInfo['but'][2] - $aObjectInfo['but'][6])/2);
            $aXpos['but'] = $this->pos['sec-x'][$circleNr] - $aLabelWidth['but'] ;
            $aYpos['but'] =  $this->pos['sec-y'][$circleNr] +  $fontsize;
            imagettftext( $image , $fontsize , 0 , $aXpos['but'] , $aYpos['but'] , $tectcolor , $this->fontpath['sec'],  $aText['but'] );
	}
	
    /**
	 * xDiff
	 *  Ergibt Laenge der Gegenkathete "X" in Pixel
	 *  aus Hypothenusen-Laenge in pixel (radiant,strahl) 
	 *  und Winkel alpha in Grad
	 *
	 * @param	str $kDistanz
	 * @param	int $alpha
	 * @return	array
	 */
	Private function xDiff( $kDistanz , $alpha , $direction = 1 ){
	    $bogenmass = deg2rad( $alpha );
	    $sinus = sin( $direction * $bogenmass );
	    return round( ( $kDistanz * $sinus ) );
	}
	
    /**
	 * yDiff
     *  Ergibt Laenge der Ankathete "Y" in Pixel
	 *  aus Hypothenusen-Laenge in pixel (radiant,strahl) 
	 *  und Winkel alpha in Grad
	 *
	 * @param	str $kDistanz
	 * @param	int $alpha
	 * @return	int length
	 */
	Private function yDiff( $kDistanz , $alpha , $direction = 1 ){
	    $bogenmass = deg2rad( $alpha );
	    $cosinus = cos( $direction * $bogenmass );
	    return round( ( $kDistanz * $cosinus ) );
	}
}


?>
