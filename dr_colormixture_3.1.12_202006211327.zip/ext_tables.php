<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Dr.DrColormixture',
            'Ctr',
            'Colormixture Control'
        );
        
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('dr_colormixture', 'Configuration/TypoScript', 'Colormixture');

    }
);
if (TYPO3_MODE === 'BE') {

    /* we do not need any pages-chooser or recursive in this content-element */
    $TCA['tt_content']['types']['list']['subtypes_excludelist']['drcolormixture_ctr']='pages,recursive';
    
    /* load flexform for plugin control */
    $TCA['tt_content']['types']['list']['subtypes_addlist']['drcolormixture_ctr'] = 'pi_flexform';
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('drcolormixture_ctr', 'FILE:EXT:dr_colormixture/Configuration/Flexforms/drcolormixture_ctr.xml');

}

